// =============================================
// Telegram Mini App + Phaser + Кицу — ПОЛНАЯ РАБОЧАЯ ВЕРСИЯ
// Исправлено для Telegram v6.0 (без CloudStorage и showPopup)
// Плавная смена анимаций, комнаты, мини-игра, адаптация
// =============================================
const tg = window.Telegram.WebApp;
tg.ready();
tg.expand();
tg.MainButton.setText("Вернуться к Хозяйке").show();
tg.MainButton.onClick(() => tg.close());
// =============================================
// СОСТОЯНИЕ ИГРЫ (убрали fridgeItems, т.к. оно временное)
// =============================================
const defaultGameState = {
  hunger: 50,
  mood: 60,
  energy: 70,
  cleanliness: 80,
  level: 1,
  devotion: 0,
  money: 300,
  lastActive: Date.now(),
  currentRoom: "gostinnaya",
  currentAnimation: "idle",
  activityInProgress: null, // null | "cooking" | "work" | "date"
  firstTime: true,
  playerName: "",
  unlockedRooms: ["gostinnaya"],
  time: 480, // 8:00 in minutes
  timeOfDay: "morning",
  upgrades: {},
  tasks: [
    "Заботьтесь о Кицу, чтобы повысить преданность и разблокировать кухню.",
  ],
  tutorialCompleted: false,
};
let gameState = { ...defaultGameState };

// =============================================
// УЛУЧШЕНИЯ
// =============================================
const upgrades = {
  better_sofa: {
    name: "Лучший диван",
    cost: 100,
    level: 3,
    room: "gostinnaya",
    effect: { mood_bonus_play: 10 },
    image: "better_sofa",
    position: { x: -200, y: 100 }, // относительная позиция
  },
  better_bed: {
    name: "Лучшая кровать",
    cost: 150,
    level: 4,
    room: "spalnya",
    effect: { energy_bonus_sleep: 20 },
    image: "better_bed",
    position: { x: 0, y: 150 },
  },
  // Добавьте больше улучшений по необходимости
};

// =============================================
// ДИАЛОГИ (добавили activity_start и activity_end из предыдущего фикса)
// =============================================
const dialogues = {
  greet: [
    `Хозяйка оставила меня здесь ждать… а ты пришёл, ${gameState.playerName}. Это приятно ♡`,
    "Я чувствую твоё тепло даже через экран… что у тебя на душе сегодня?",
    "Ты вернулся ко мне… Кицу рада. Очень рада.",
    "Ш-ш-ш… тише. Я всё ещё слышу шаги Хозяйки где-то рядом…",
  ],
  after_feed: [
    "Спасибо… это было так вкусно. Ты всегда знаешь, что мне нужно ♡",
    "Кицу наелась… теперь хочется просто посидеть рядом с тобой.",
    "Каждый раз, когда ты меня кормишь, я думаю о том, как Хозяйка была бы довольна тобой.",
    "…тепло внутри. И не только от еды.",
  ],
  low_mood: [
    "Мне немного одиноко… побудь со мной, ладно?",
    "Я скучаю по голосу Хозяйки… но твой голос тоже успокаивает.",
    "Не уходи далеко, хорошо? Кицу не хочет оставаться одна.",
  ],
  care: [
    "Ты так заботишься… Хозяйка выбрала бы именно такого щеночка.",
    "Кицу чувствует твои пальцы даже здесь… это очень нежно ♡",
    "Продолжай… мне нравится, когда ты рядом.",
    "Ты мой хороший… Хозяйка будет гордиться.",
  ],
  happy: [
    "Мне так хорошо рядом с тобой… хвостики сами шевелятся ♡",
    "Кицу счастлива… спасибо, что ты есть.",
  ],
  sleep: [
    "Спокойной ночи… Кицу будет видеть сны о Хозяйке.",
    "Энергия восстанавливается… спасибо, что уложил меня.",
  ],
  wash: [
    "Я чистая и свежая… как после горного воздуха ♡",
    "Теперь Кицу готова к новым приключениям.",
  ],
  toilet: ["Спасибо… теперь всё в порядке.", "Кицу чувствует себя легче."],
  work: [
    "Хорошо поработали… Хозяйка будет довольна.",
    "Вернулись с работы… устала, но рада видеть тебя.",
  ],
  date: [
    "Свидание было волшебным… спасибо ♡",
    "Кицу чувствует тепло от времени с тобой.",
  ],
  minigame_success: [
    "Вкусно получилось! Ты молодец ♡",
    "Кицу обожает, когда ты готовишь.",
  ],
  minigame_fail: [
    "Ой… что-то пошло не так. Попробуем ещё раз?",
    "Ничего страшного, в следующий раз получится лучше.",
  ],
  level_up: {
    2: [
      "Поздравляю, ты повысил уровень!",
      "Теперь ты достаточно предан, чтобы готовить для меня на кухне.",
      "Хозяйка была бы рада видеть, как ты заботишься обо мне.",
    ],
    3: [
      "Уровень повышен!",
      "Теперь доступна спальня. Ты можешь ухаживать за моим отдыхом.",
      "Это знак доверия от меня ♡",
    ],
    4: [
      "Отлично! Новый уровень.",
      "Ванная открыта. Чистота важна для нас.",
      "Ты становишься настоящим щеночком Хозяйки.",
    ],
    5: [
      "Ты вырос, щеночек!",
      "Теперь ты можешь выходить из дома и работать.",
      "Но возвращайся поскорее, Кицу будет ждать ♡",
    ],
  },
  activity_start: {
    cooking: ["Начинаем готовить... ♡", "Кицу ждёт вкусненькое!"],
    work: ["Ушла на работу... скоро вернусь", "Хозяйка будет довольна"],
    date: ["Мы идём на свидание... ♡", "Так волнительно!"],
  },
  activity_end: {
    cooking: ["Готовка закончена... пахнет вкусно ♡", "Вкусно получилось!"],
    work: [
      "Вернулась с работы... устала, но довольна",
      "День прошёл продуктивно",
    ],
    date: ["Свидание было прекрасным... спасибо ♡", "Кицу счастлива"],
  },
};
function randomItem(arr) {
  if (!Array.isArray(arr) || arr.length === 0) return "Кицу улыбается...";
  return arr[Math.floor(Math.random() * arr.length)].replace(
    /\{playerName\}/g,
    gameState.playerName
  );
}
function showDialogue(
  text,
  options = null,
  isThought = false,
  isCutscene = false
) {
  const box = document.getElementById("dialogue-box");
  if (!box) return; // защита

  const textEl = document.getElementById("dialogue-text");
  const btnContainer = box.querySelector(".dialogue-buttons");

  btnContainer.innerHTML = "";
  box.classList.remove("hidden", "cutscene", "thought");

  if (isCutscene) box.classList.add("cutscene");
  if (isThought) box.classList.add("thought");

  textEl.textContent = text;

  if (options) {
    options.forEach((opt) => {
      const b = document.createElement("button");
      b.textContent = opt.text;
      b.onclick = () => {
        box.classList.add("hidden");
        opt.action();
      };
      btnContainer.appendChild(b);
    });
  }
}
// =============================================
// PHASER СЦЕНЫ — ВСЕ ОПРЕДЕЛЕНЫ ДО ЗАПУСКА
// =============================================
// BootScene — загрузка
class BootScene extends Phaser.Scene {
  constructor() {
    super("Boot");
  }
  preload() {
    // Показываем загрузочный экран
    const loadingOverlay = document.getElementById("loading-overlay");
    if (loadingOverlay) loadingOverlay.style.display = "flex";

    console.log("[Boot] Начало загрузки ассетов...");
    // Загрузка анимаций и изображений
    this.load.video("kitsune_idle", "assets/animation/kitsu_idle.webm");
    this.load.video("kitsune_happy", "assets/animation/kitsu_happy.webm");
    this.load.video("kitsune_thinking", "assets/animation/kitsu_thinking.webm");
    this.load.video("kitsune_petting", "assets/animation/kitsu_petting.webm");
    this.load.image("kitsune_fallback", "assets/image/kitsu.png");
    this.load.image("kitsu_intro", "assets/image/kitsu_intro.png"); // Специальное изображение для intro

    // Загрузка фонов для комнат с вариациями по времени суток
    const rooms = ["gostinnaya", "kuchnya", "spalnya", "vannaya", "prihozhaya"];
    const times = ["morning", "day", "evening", "night"];
    rooms.forEach((room) => {
      times.forEach((time) => {
        this.load.image(
          `${room}_${time}`,
          `assets/image/rooms/${room}_${time}.jpg`
        );
      });
    });

    this.load.image("ingredient_1", "assets/image/minigame/ingredient1.png");
    this.load.image("ingredient_2", "assets/image/minigame/ingredient2.png");
    this.load.image("ingredient_3", "assets/image/minigame/ingredient3.png");
    this.load.image("cooking_pot", "assets/image/minigame/pot.jpg");
    this.load.image("better_sofa", "assets/image/upgrades/better_sofa.png");
    this.load.image("better_bed", "assets/image/upgrades/better_bed.png");

    this.load.on("fileprogress", (file) => {
      console.log(
        `[Загрузка] ${file.key} — ${Math.round(file.progress * 100)}%`
      );
    });
    this.load.on("filecomplete", (key) => {
      console.log(`[Готов] ${key}`);
    });
    this.load.on("complete", () => {
      console.log("[Boot] Загрузка завершена");
      if (loadingOverlay) loadingOverlay.style.display = "none";
    });
  }
  create() {
    this.scene.start(gameState.firstTime ? "Intro" : gameState.currentRoom);
  }
}

// IntroScene (без изменений, но с фиксами из предыдущих)
class IntroScene extends Phaser.Scene {
  constructor() {
    super("Intro");
  }

  create() {
    // Скрываем интерфейс
    document
      .querySelectorAll(
        ".status-bar, #room-actions, #time-display, #tasks-panel, #tasks-toggle"
      )
      .forEach((el) => el?.classList.add("hidden"));

    // Чёрный фон
    let blackBg = this.add
      .rectangle(0, 0, this.scale.width, this.scale.height, 0x000000)
      .setOrigin(0, 0)
      .setDepth(-1);

    // Story steps
    const storySteps = [
      {
        text: "…Глаза медленно открываются.\nГде я?.. Всё вокруг чужое, незнакомое…",
        isThought: true,
      },
      {
        text: "В памяти только обрывки…\nКакой-то контракт… подпись… и темнота.",
        isThought: true,
      },
      {
        text: "Добро пожаловать домой, маленький щеночек ♡\nКак тебя зовут?",
        isThought: false,
      },
    ];

    let currentStep = 0;
    let kitsuSprite = null;

    const showNextStep = () => {
      if (currentStep >= storySteps.length) {
        this.input.off("pointerdown");

        // Модалка для имени
        const modalOverlay = document.createElement("div");
        modalOverlay.id = "name-modal-overlay";
        modalOverlay.style.cssText = `
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.85);
          z-index: 99998;
          backdrop-filter: blur(6px);
          display: flex;
          align-items: center;
          justify-content: center;
        `;

        const modal = document.createElement("div");
        modal.id = "name-modal";
        modal.style.cssText = `
          background: linear-gradient(135deg, rgba(30,20,60,0.98), rgba(50,30,90,0.95));
          border: 3px solid #c084fc;
          border-radius: 20px;
          padding: 40px 50px;
          max-width: 460px;
          width: 92%;
          text-align: center;
          color: #f0e8ff;
          z-index: 99999;
          box-shadow: 0 15px 60px rgba(0,0,0,0.7), inset 0 0 30px rgba(167,139,250,0.15);
          position: relative;
        `;

        modal.innerHTML = `
          <h2 style="margin: 0 0 24px; font-size: 26px; text-shadow: 0 2px 10px rgba(0,0,0,0.6);">
            Как тебя зовут, мой хороший?
          </h2>
          <input type="text" id="name-input" placeholder="Твоё имя…" autocomplete="off" style="
            width: 100%;
            padding: 16px 20px;
            font-size: 20px;
            border-radius: 12px;
            border: 2px solid #a78bfa;
            background: rgba(255,255,255,0.06);
            color: white;
            outline: none;
            transition: all 0.3s;
            box-shadow: inset 0 2px 8px rgba(0,0,0,0.4);
            margin-bottom: 24px;
          ">
          <button id="confirm-name" style="
            padding: 16px 60px;
            font-size: 20px;
            background: linear-gradient(135deg, #7c3aed, #a78bfa);
            color: white;
            border: none;
            border-radius: 14px;
            cursor: pointer;
            box-shadow: 0 6px 20px rgba(124,58,237,0.5);
            transition: all 0.25s;
          ">Продолжить</button>
        `;

        modalOverlay.appendChild(modal);
        document.body.appendChild(modalOverlay);

        const input = document.getElementById("name-input");
        const confirmBtn = document.getElementById("confirm-name");

        input.addEventListener("focus", () => {
          input.style.borderColor = "#c084fc";
          input.style.boxShadow = "0 0 15px rgba(192,132,252,0.6)";
        });
        input.addEventListener("blur", () => {
          input.style.borderColor = "#a78bfa";
          input.style.boxShadow = "inset 0 2px 8px rgba(0,0,0,0.4)";
        });

        setTimeout(() => {
          input.focus();
          input.select();
        }, 150);

        const confirmName = () => {
          const name = input.value.trim() || "Щеночек";
          gameState.playerName = name;
          gameState.firstTime = false;
          this.saveProgress();

          const dialogueBox = document.getElementById("dialogue-box");
          if (dialogueBox) dialogueBox.classList.add("hidden");

          if (kitsuSprite) kitsuSprite.destroy();

          if (blackBg) blackBg.destroy();

          modalOverlay.remove();

          this.cameras.main.fadeOut(800, 0, 0, 0);
          this.cameras.main.once("camerafadeoutcomplete", () => {
            this.scene.start("gostinnaya");
          });
        };

        confirmBtn.onclick = confirmName;
        confirmBtn.onpointerdown = (e) => e.preventDefault();

        input.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            confirmName();
          }
        });

        modalOverlay.addEventListener("click", (e) => {
          if (e.target === modalOverlay) {
            confirmName();
          }
        });

        return;
      }

      const step = storySteps[currentStep];

      showDialogue(step.text, null, step.isThought, true);

      if (!step.isThought) {
        if (kitsuSprite) kitsuSprite.destroy();

        kitsuSprite = this.add
          .image(this.scale.width / 2, this.scale.height * 0.48, "kitsu_intro")
          .setOrigin(0.5)
          .setAlpha(0);

        const baseScale = Math.min(
          (this.scale.width * 0.78) / 512,
          (this.scale.height * 0.68) / 1024
        );
        kitsuSprite.setScale(baseScale);

        this.tweens.add({
          targets: kitsuSprite,
          alpha: 1,
          duration: 700,
          ease: "Sine.easeOut",
        });
      } else if (kitsuSprite) {
        this.tweens.add({
          targets: kitsuSprite,
          alpha: 0,
          duration: 500,
          ease: "Sine.easeIn",
          onComplete: () => {
            kitsuSprite?.destroy();
            kitsuSprite = null;
          },
        });
      }

      currentStep++;
    };

    showNextStep();

    this.input.on("pointerdown", showNextStep);
  }

  saveProgress() {
    try {
      localStorage.setItem("kitsuSave", JSON.stringify(gameState));
      console.log("[Intro] Прогресс сохранён");
    } catch (e) {
      console.warn("[Save] localStorage ошибка:", e);
    }

    if (tg?.CloudStorage && parseFloat(tg.version) >= 7.0) {
      tg.CloudStorage.setItem("kitsuSave", JSON.stringify(gameState), (err) => {
        if (err) console.warn("[Cloud] Ошибка:", err);
        else console.log("[Cloud] Сохранено");
      });
    }
  }
}

class LevelUpScene extends Phaser.Scene {
  constructor() {
    super("LevelUp");
  }
  init(data) {
    this.level = data.level;
  }
  create() {
    document.querySelector(".status-bar")?.classList.add("hidden");
    document.getElementById("room-actions")?.classList.add("hidden");
    document.getElementById("time-display")?.classList.add("hidden");
    document.getElementById("tasks-panel")?.classList.add("hidden");

    this.add
      .rectangle(0, 0, this.scale.width, this.scale.height, 0x000000)
      .setOrigin(0, 0)
      .setDepth(-1);
    let kitsuImage = this.add
      .image(this.scale.width / 2, this.scale.height / 2, "kitsu_intro")
      .setOrigin(0.5)
      .setScale(
        Math.min(
          (this.scale.width * 0.8) / 512,
          (this.scale.height * 0.6) / 512
        )
      )
      .setAlpha(1);
    const storySteps = dialogues.level_up[this.level] || ["Уровень повышен!"];
    let currentStep = 0;
    const showNextStep = () => {
      if (currentStep >= storySteps.length) {
        kitsuImage.destroy();
        this.scene.start(gameState.currentRoom);
        return;
      }
      showDialogue(
        storySteps[currentStep],
        [{ text: "Дальше", action: showNextStep }],
        false,
        true
      );
      currentStep++;
    };
    showNextStep();
  }
}

class BaseRoomScene extends Phaser.Scene {
  constructor(roomKey, bgKey) {
    super(roomKey);
    this.roomKey = roomKey;
    this.bgKey = bgKey;
    this.isActionLocked = false; // Lock для предотвращения спама
  }
  create() {
    this.cameras.main.fadeIn(800, 0, 0, 0);

    document.querySelector(".status-bar")?.classList.remove("hidden");
    document.getElementById("room-actions")?.classList.remove("hidden");
    document.getElementById("time-display")?.classList.remove("hidden");
    document.getElementById("tasks-panel")?.classList.remove("hidden");

    this.updateBackground();
    this.kitsuneContainer = this.add
      .container(this.scale.width / 2, this.scale.height * 0.5)
      .setDepth(10);
    this.currentVideo = null;
    this.kitsune = null;
    this.scale.on("resize", this.resizeHandler, this);
    this.resizeHandler(this.scale);
    this.loadGameState();
    this.upgradeSprites = [];
    this.loadUpgrades();
    this.calculateOfflineProgress();
    if (!gameState.activityInProgress) {
      this.playAnimation("idle");
    } else {
      this.hideKitsu();
    }
    this.time.addEvent({
      delay: 1000,
      callback: () => this.advanceTime(1),
      loop: true,
    });
    if (this.roomKey === "gostinnaya" && !gameState.tutorialCompleted) {
      this.startTutorial();
    }
    this.createRoomActions();
    this.setupSwipe();
    this.createTasksToggle();
  }
  createTasksToggle() {
    const toggleBtn = document.getElementById("tasks-toggle");
    if (!toggleBtn) {
      const newToggleBtn = document.createElement("button");
      newToggleBtn.id = "tasks-toggle";
      newToggleBtn.textContent = "Задания";
      newToggleBtn.style.cssText = `
        position: absolute;
        top: 50px;
        right: 10px;
        padding: 8px 16px;
        background: #1e90ff;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        z-index: 25;
      `;
      newToggleBtn.onclick = () => {
        const panel = document.getElementById("tasks-panel");
        panel.classList.toggle("hidden");
      };
      document.body.appendChild(newToggleBtn);
    }
    document.getElementById("tasks-panel")?.classList.add("hidden");
  }
  loadUpgrades() {
    this.destroyUpgrades();
    for (let key in upgrades) {
      if (gameState.upgrades[key] && upgrades[key].room === this.roomKey) {
        const spr = this.add
          .image(
            this.scale.width / 2 + upgrades[key].position.x,
            this.scale.height / 2 + upgrades[key].position.y,
            upgrades[key].image
          )
          .setOrigin(0.5);
        this.upgradeSprites.push(spr);
      }
    }
  }
  destroyUpgrades() {
    this.upgradeSprites.forEach((spr) => spr.destroy());
    this.upgradeSprites = [];
  }
  startTutorial() {
    const tutorialSteps = [
      `Привет, ${gameState.playerName}! Чтобы повысить уровень, заботься обо мне, увеличивай преданность (play, talk, care).`,
      "Каждое действие занимает время, следи за временем дня.",
      "Задания в правом верхнем углу. Выполняй их, чтобы прогрессировать.",
    ];
    let step = 0;
    const showNext = () => {
      if (step >= tutorialSteps.length) {
        gameState.tutorialCompleted = true;
        this.saveProgress();
        return;
      }
      showDialogue(tutorialSteps[step], [{ text: "Дальше", action: showNext }]);
      step++;
    };
    showNext();
  }
  advanceTime(minutes) {
    gameState.time += minutes;
    gameState.time %= 1440;
    this.updateTimeOfDay();
    gameState.hunger = Math.min(100, gameState.hunger + minutes * 0.05);
    gameState.energy = Math.max(0, gameState.energy - minutes * 0.03);
    gameState.cleanliness = Math.max(0, gameState.cleanliness - minutes * 0.01);
    if (gameState.hunger > 75)
      gameState.mood = Math.max(20, gameState.mood - minutes * 0.02);
    if (
      gameState.mood < 30 &&
      gameState.currentAnimation !== "thinking" &&
      !gameState.activityInProgress
    ) {
      this.playAnimation("thinking");
    }
    this.updateUI();
    this.updateBackground();
    this.saveProgress();
  }
  updateTimeOfDay() {
    const hour = Math.floor(gameState.time / 60);
    if (hour >= 6 && hour < 12) gameState.timeOfDay = "morning";
    else if (hour < 18) gameState.timeOfDay = "day";
    else if (hour < 22) gameState.timeOfDay = "evening";
    else gameState.timeOfDay = "night";
  }
  updateBackground() {
    if (this.bg) this.bg.destroy();
    if (gameState.activityInProgress) {
      this.bg = this.add
        .rectangle(0, 0, this.scale.width, this.scale.height, 0x000000)
        .setOrigin(0, 0)
        .setDepth(-1);
    } else {
      const fullKey = `${this.bgKey}_${gameState.timeOfDay}`;
      this.bg = this.add
        .image(this.scale.width / 2, this.scale.height / 2, fullKey)
        .setOrigin(0.5)
        .setDisplaySize(this.scale.width, this.scale.height)
        .setDepth(-1);
    }
  }
  hideKitsu() {
    if (this.kitsune) {
      this.kitsune.destroy();
      this.kitsune = null;
    }
    gameState.currentAnimation = "hidden";
  }
  showKitsu() {
    gameState.activityInProgress = null;
    this.updateBackground();
    const key = gameState.activityInProgress || "default";
    const endings = dialogues.activity_end?.[key] || ["Кицу вернулась ♡"];
    showDialogue(randomItem(endings));
    this.playAnimation("idle");
  }
  setupSwipe() {
    let startX = 0;
    let isSwiping = false;
    const container = document.getElementById("game-container");
    if (!container) return;
    container.addEventListener(
      "touchstart",
      (e) => {
        if (isSwiping) return;
        startX = e.changedTouches[0].screenX;
      },
      { passive: true }
    );
    container.addEventListener(
      "touchend",
      (e) => {
        if (isSwiping) return;
        const endX = e.changedTouches[0].screenX;
        const diff = startX - endX;
        if (Math.abs(diff) < 100) return;
        isSwiping = true;
        setTimeout(() => (isSwiping = false), 600);
        const rooms = [
          "gostinnaya",
          "kuchnya",
          "spalnya",
          "vannaya",
          "prihozhaya",
        ];
        let idx = rooms.indexOf(gameState.currentRoom);
        if (idx === -1) idx = 0;
        idx =
          diff > 0
            ? (idx + 1) % rooms.length
            : (idx - 1 + rooms.length) % rooms.length;
        const nextRoom = rooms[idx];
        if (gameState.unlockedRooms.includes(nextRoom)) {
          this.switchRoom(nextRoom);
        } else {
          showDialogue("Эта комната ещё не открыта!");
        }
      },
      { passive: true }
    );
  }
  switchRoom(nextRoom) {
    if (this.switchingRoom) return;
    this.switchingRoom = true;
    const camera = this.cameras?.main;
    if (!camera) {
      this.scene.start(nextRoom);
      gameState.currentRoom = nextRoom;
      this.switchingRoom = false;
      return;
    }
    camera.fadeOut(380, 0, 0, 0);
    camera.once(Phaser.Cameras.Scene2D.Events.FADE_OUT_COMPLETE, () => {
      this.scene.start(nextRoom);
      gameState.currentRoom = nextRoom;
      this.switchingRoom = false;
    });
    this.time.delayedCall(500, () => {
      if (this.switchingRoom) {
        this.scene.start(nextRoom);
        gameState.currentRoom = nextRoom;
        this.switchingRoom = false;
      }
    });
  }
  resizeHandler(g) {
    const w = g.width || window.innerWidth;
    const h = g.height || window.innerHeight;
    this.cameras.resize(w, h);
    if (this.bg && !gameState.activityInProgress) {
      this.bg.setDisplaySize(w, h);
    } else if (this.bg) {
      this.bg.setSize(w, h);
    }
    this.kitsuneContainer.setPosition(w / 2, h * 0.5);
    if (this.kitsune) {
      const baseScale = Math.min(
        (w * 0.82) / this.kitsune.width,
        (h * 0.75) / this.kitsune.height
      );
      this.kitsune.setScale(baseScale * 0.92);
    }
    this.createRoomActions();
  }
  refitCharacter() {
    if (!this.kitsune || this.kitsune.width < 10) return;
    const w = this.scale.width;
    const h = this.scale.height;
    let scale = Math.min(
      (w * 0.8) / this.kitsune.width,
      (h * 0.65) / this.kitsune.height
    );
    const aspect = w / h;
    if (aspect < 0.7) scale *= 0.85;
    scale = Math.min(scale, 1.4);
    this.kitsune.setScale(scale);
    this.kitsuneContainer.setPosition(w / 2, h * 0.52);
  }
  playAnimation(key) {
    if (gameState.activityInProgress) return;
    gameState.currentAnimation = key;
    if (this.currentVideo) this.currentVideo.destroy();
    const videoKey = `kitsune_${key}`;
    if (this.cache.video.exists(videoKey)) {
      const video = this.add.video(0, 0, videoKey).setOrigin(0.5).setMute(true);
      this.kitsuneContainer.add(video);
      this.currentVideo = video;
      this.kitsune = video;
      video.play(true);
      video.setLoop(true);
      video.once("play", () => this.refitCharacter());
      video.once("error", (err) => {
        console.error("[Video Error]", videoKey, err);
        this.playStaticFallback();
      });
    } else {
      this.playStaticFallback();
    }
  }
  playStaticFallback() {
    if (this.currentVideo) this.currentVideo.destroy();
    const fb = this.add.image(0, 0, "kitsune_fallback").setOrigin(0.5);
    this.kitsuneContainer.add(fb);
    this.kitsune = fb;
    this.refitCharacter();
    this.currentVideo = null;
  }
  checkLevelUp() {
    const needed = gameState.level * 120;
    if (gameState.devotion >= needed) {
      gameState.level++;
      gameState.devotion -= needed;
      showDialogue(`🎉 Уровень Кицу повышен до ${gameState.level}!`);
      if (
        gameState.level === 2 &&
        !gameState.unlockedRooms.includes("kuchnya")
      ) {
        gameState.unlockedRooms.push("kuchnya");
        showDialogue("Открыта новая комната: Кухня!");
      }
      if (
        gameState.level === 3 &&
        !gameState.unlockedRooms.includes("spalnya")
      ) {
        gameState.unlockedRooms.push("spalnya");
        showDialogue("Открыта новая комната: Спальня!");
      }
      if (
        gameState.level === 4 &&
        !gameState.unlockedRooms.includes("vannaya")
      ) {
        gameState.unlockedRooms.push("vannaya");
        showDialogue("Открыта новая комната: Ванная!");
      }
      if (
        gameState.level === 5 &&
        !gameState.unlockedRooms.includes("prihozhaya")
      ) {
        gameState.unlockedRooms.push("prihozhaya");
        showDialogue("Открыта новая комната: Прихожая!");
      }
      gameState.tasks = [
        `Повысьте уровень до ${
          gameState.level + 1
        }, чтобы разблокировать следующую возможность.`,
      ];
      this.updateUI();
      this.saveProgress();
      this.scene.start("LevelUp", { level: gameState.level });
    }
  }
  startDateMinigame() {
    if (this.isActionLocked) return;
    this.isActionLocked = true;
    setTimeout(() => (this.isActionLocked = false), 1000);
    gameState.activityInProgress = "date";
    this.hideKitsu();
    this.updateBackground();
    const kitsuImg = this.add
      .image(this.scale.width / 2, this.scale.height * 0.38, "kitsune_fallback")
      .setOrigin(0.5)
      .setScale(
        Math.min(
          (this.scale.width * 0.7) / 512,
          (this.scale.height * 0.55) / 512
        )
      );
    const storyTexts = [
      "Вы встретились у фонтана в парке… вечер тёплый.",
      "Кицу немного смущается, но её хвостики дрожат от счастья ♡",
      "Вы берёте её за руку… она прижимается ближе.",
      "Звёзды над вами… кажется, время остановилось.",
      "Кицу шепчет: «Спасибо, что ты со мной…»",
    ];
    let step = 0;
    const textObj = this.add
      .text(this.scale.width / 2, this.scale.height * 0.78, storyTexts[0], {
        fontSize: `${Math.min(24, this.scale.width / 20)}px`,
        color: "#ffe4e1",
        align: "center",
        wordWrap: { width: this.scale.width * 0.88 },
      })
      .setOrigin(0.5);
    const nextBtn = this.add
      .text(this.scale.width / 2, this.scale.height - 70, "→ Дальше", {
        fontSize: "28px",
        color: "#ffffff",
        backgroundColor: "#9d4edd",
        padding: { x: 24, y: 12 },
      })
      .setOrigin(0.5)
      .setInteractive();
    nextBtn.on("pointerdown", () => {
      step++;
      if (step < storyTexts.length) {
        textObj.setText(storyTexts[step]);
      } else {
        gameState.mood = Math.min(100, gameState.mood + 40);
        gameState.devotion += 45;
        this.advanceTime(Math.floor(Math.random() * 11 + 5));
        kitsuImg.destroy();
        textObj.destroy();
        nextBtn.destroy();
        this.showKitsu();
        this.checkLevelUp();
        this.updateUI();
      }
    });
    showDialogue(randomItem(dialogues.activity_start.date));
  }
  createRoomActions() {
    const old = document.getElementById("room-actions");
    if (old) old.remove();
    const container = document.createElement("div");
    container.id = "room-actions";
    container.style.cssText = `
      position: absolute;
      bottom: env(safe-area-inset-bottom, 16px);
      left: 0;
      right: 0;
      display: flex;
      justify-content: center;
      gap: 14px;
      padding: 0 16px;
      padding-bottom: 8px;
      pointer-events: auto;
      z-index: 35;
      flex-wrap: wrap;
      user-select: none;
    `;
    let html = "";
    if (gameState.activityInProgress) {
      let buttonText = "Вернуться";
      let bgColor = "#9d4edd";
      if (gameState.activityInProgress === "cooking")
        buttonText = "Готовка... подождать";
      if (gameState.activityInProgress === "work")
        buttonText = "Работает... подождать";
      if (gameState.activityInProgress === "date")
        buttonText = "Завершить свидание";
      bgColor = "#c71585";
      if (gameState.activityInProgress === "shop")
        buttonText = "Закрыть магазин";
      html = `
        <button id="returnFromActivity"
          style="background: ${bgColor}; color: white; border: none; padding: 16px 36px; font-size: 20px; border-radius: 12px; min-width: 220px; touch-action: manipulation; box-shadow: 0 4px 12px rgba(0,0,0,0.4);">
          ${buttonText}
        </button>
      `;
    } else {
      switch (this.roomKey) {
        case "kuchnya":
          html = `
            <button id="cook">Приготовить</button>
            <button id="feed">Покормить</button>
            <button id="buy_food">Купить продукты</button>
          `;
          break;
        case "spalnya":
          html = `<button id="sleep">Уложить спать</button>`;
          break;
        case "gostinnaya":
          html = `
            <button id="play">Поиграть</button>
            <button id="talk">Поговорить</button>
            <button id="care">Позаботиться</button>
          `;
          if (gameState.level >= 3)
            html += `<button id="shop">Магазин</button>`;
          break;
        case "vannaya":
          html = `
            <button id="wash">Помыть Кицу</button>
            <button id="toilet">Сходить в туалет</button>
          `;
          break;
        case "prihozhaya":
          html = `
            <button id="work">Пойти на работу</button>
            <button id="date">Пойти на свидание</button>
          `;
          break;
      }
    }
    container.innerHTML = html;
    document.body.appendChild(container);

    const returnBtn = document.getElementById("returnFromActivity");
    if (returnBtn) {
      returnBtn.onclick = () => {
        this.showKitsu();
        this.updateUI();
      };
    }

    const safeClick = (id, fn) => {
      const el = document.getElementById(id);
      if (el)
        el.onclick = () => {
          if (this.isActionLocked) return;
          this.isActionLocked = true;
          setTimeout(() => (this.isActionLocked = false), 1000);
          fn();
        };
    };
    safeClick("cook", () => {
      this.startCookingMinigame();
      gameState.devotion += 10;
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
    });
    safeClick("feed", () => {
      gameState.hunger = Math.max(0, gameState.hunger - 28);
      gameState.mood = Math.min(100, gameState.mood + 15);
      gameState.devotion += 12;
      this.playAnimation("happy");
      showDialogue(randomItem(dialogues.after_feed));
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("buy_food", () => {
      if (gameState.money >= 40) {
        gameState.money -= 40;
        showDialogue("Продукты куплены!");
        gameState.devotion += 5;
        this.checkLevelUp();
      } else {
        showDialogue("Не хватает денег...");
      }
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("sleep", () => {
      gameState.energy = Math.min(100, gameState.energy + 30);
      gameState.devotion += 10;
      this.playAnimation("sleep");
      showDialogue(randomItem(dialogues.sleep));
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("wash", () => {
      gameState.mood = Math.min(100, gameState.mood + 20);
      gameState.devotion += 8;
      this.playAnimation("petting");
      showDialogue(randomItem(dialogues.wash));
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("toilet", () => {
      showDialogue(randomItem(dialogues.toilet));
      gameState.devotion += 3;
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
    });
    safeClick("work", () => {
      gameState.devotion += 15;
      gameState.money = Math.min(1000, gameState.money + 25);
      showDialogue(randomItem(dialogues.work));
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("date", () => this.startDateMinigame());
    safeClick("play", () => {
      gameState.mood = Math.min(100, gameState.mood + 20);
      gameState.devotion += 10;
      this.playAnimation("happy");
      showDialogue("Кицу весело играет с тобой ♡");
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("talk", () => {
      showDialogue(randomItem(dialogues.greet));
      gameState.mood = Math.min(100, gameState.mood + 10);
      gameState.devotion += 5;
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("care", () => {
      gameState.mood = Math.min(100, gameState.mood + 15);
      gameState.devotion += 8;
      this.playAnimation("petting");
      showDialogue(randomItem(dialogues.care));
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
    safeClick("shop", () => this.startShop());
  }
  startShop() {
    if (this.isActionLocked) return;
    this.isActionLocked = true;
    setTimeout(() => (this.isActionLocked = false), 1000);
    gameState.activityInProgress = "shop";
    this.hideKitsu();
    this.updateBackground();
    showDialogue("Добро пожаловать в магазин!");
    const availableUpgrades = Object.keys(upgrades).filter(
      (key) =>
        !gameState.upgrades[key] && gameState.level >= upgrades[key].level
    );
    if (availableUpgrades.length === 0) {
      showDialogue("Нет доступных улучшений.");
      this.showKitsu();
      return;
    }
    const textObj = this.add
      .text(
        this.scale.width / 2,
        this.scale.height / 2,
        "Доступные улучшения:",
        {
          fontSize: "24px",
          color: "#ffffff",
        }
      )
      .setOrigin(0.5, 1);
    availableUpgrades.forEach((key, i) => {
      const btn = this.add
        .text(
          this.scale.width / 2,
          this.scale.height / 2 + 50 * (i + 1),
          `${upgrades[key].name} - ${upgrades[key].cost} монет`,
          {
            fontSize: "20px",
            color: "#ffffff",
          }
        )
        .setOrigin(0.5)
        .setInteractive();
      btn.on("pointerdown", () => {
        if (gameState.money >= upgrades[key].cost) {
          gameState.money -= upgrades[key].cost;
          gameState.upgrades[key] = true;
          showDialogue("Улучшение куплено!");
          textObj.destroy();
          availableUpgrades.forEach((k) => {
            this.children
              .getAll()
              .find((c) => c.text && c.text.includes(upgrades[k].name))
              ?.destroy();
          });
          this.showKitsu();
          this.loadUpgrades();
        } else {
          showDialogue("Не хватает денег.");
        }
      });
    });
    this.advanceTime(Math.floor(Math.random() * 11 + 5));
  }
  calculateOfflineProgress() {
    const now = Date.now();
    const minutes = (now - gameState.lastActive) / 60000;
    if (minutes > 10) {
      const hungerGain = Math.min(50, minutes * 1.1);
      gameState.hunger = Math.min(100, gameState.hunger + hungerGain);
      if (tg.version && parseFloat(tg.version) >= 7.0) {
        tg.showPopup({
          title: "Кицу ждала тебя…",
          message: `Пока тебя не было, я немного проголодалась (+${Math.floor(
            hungerGain
          )}%)`,
          buttons: [{ type: "ok" }],
        });
      } else {
        alert(
          `Кицу проголодалась за время твоего отсутствия (+${Math.floor(
            hungerGain
          )}%)`
        );
      }
    }
    gameState.lastActive = now;
    this.saveProgress();
  }
  startCookingMinigame() {
    if (this.isActionLocked) return;
    this.isActionLocked = true;
    setTimeout(() => (this.isActionLocked = false), 1000);
    gameState.activityInProgress = "cooking";
    this.hideKitsu();
    this.updateBackground();
    showDialogue(randomItem(dialogues.activity_start.cooking));
    let addedIngredients = 0;
    const pot = this.add
      .image(this.scale.width / 2, this.scale.height / 2 + 100, "cooking_pot")
      .setScale(0.6)
      .setInteractive();
    const ingredients = ["ingredient_1", "ingredient_2", "ingredient_3"];
    ingredients.forEach((key, i) => {
      const ing = this.add
        .image(100 + i * 150, 200, key)
        .setScale(0.5)
        .setInteractive();
      this.input.setDraggable(ing);
      ing.on("dragstart", () => ing.setTint(0xaaaaaa));
      ing.on("drag", (pointer, x, y) => {
        ing.x = x;
        ing.y = y;
      });
      ing.on("dragend", () => {
        ing.clearTint();
        if (
          Phaser.Geom.Intersects.RectangleToRectangle(
            ing.getBounds(),
            pot.getBounds()
          )
        ) {
          ing.destroy();
          addedIngredients++;
          showDialogue("Ингредиент добавлен!");
        }
      });
    });
    const finishBtn = this.add
      .text(this.scale.width / 2, this.scale.height - 100, "Готово!", {
        fontSize: "32px",
        color: "#ffffff",
        backgroundColor: "#4a30ff",
        padding: { x: 20, y: 10 },
      })
      .setOrigin(0.5)
      .setInteractive();
    finishBtn.on("pointerdown", () => {
      if (addedIngredients >= 2) {
        gameState.hunger = Math.max(0, gameState.hunger - 40);
        gameState.mood = Math.min(100, gameState.mood + 25);
        gameState.devotion += 10;
        showDialogue(randomItem(dialogues.minigame_success));
      } else {
        showDialogue(randomItem(dialogues.minigame_fail));
      }
      this.children.list
        .filter((child) => child !== this.bg && child !== this.kitsuneContainer)
        .forEach((child) => child.destroy());
      this.showKitsu();
      this.checkLevelUp();
      this.advanceTime(Math.floor(Math.random() * 11 + 5));
      this.updateUI();
    });
  }
  updateUI() {
    const hungerBar = document.getElementById("hunger-bar");
    if (hungerBar) hungerBar.style.width = gameState.hunger + "%";
    const moodBar = document.getElementById("mood-bar");
    if (moodBar) moodBar.style.width = gameState.mood + "%";
    const energyBar = document.getElementById("energy-bar");
    if (energyBar) energyBar.style.width = gameState.energy + "%";
    const cleanlinessBar = document.getElementById("cleanliness-bar");
    if (cleanlinessBar)
      cleanlinessBar.style.width = gameState.cleanliness + "%";
    const timeEl = document.getElementById("time");
    if (timeEl) {
      const h = Math.floor(gameState.time / 60)
        .toString()
        .padStart(2, "0");
      const m = (gameState.time % 60).toString().padStart(2, "0");
      timeEl.textContent = `${h}:${m}`;
    }
    const tasksList = document.getElementById("tasks-list");
    if (tasksList) {
      tasksList.innerHTML = gameState.tasks
        .map((t) => `<li>${t}</li>`)
        .join("");
    }
    const moneyEl = document.getElementById("money");
    if (moneyEl) moneyEl.textContent = Math.floor(gameState.money);
    const levelEl = document.getElementById("level");
    if (levelEl) levelEl.textContent = gameState.level;
  }
  saveProgress() {
    try {
      localStorage.setItem("kitsuSave", JSON.stringify(gameState));
      console.log("[Save] Сохранено в localStorage");
    } catch (e) {
      console.warn("[Save] localStorage ошибка:", e);
    }
    if (tg.CloudStorage && tg.version && parseFloat(tg.version) >= 7.0) {
      tg.CloudStorage.setItem("kitsuSave", JSON.stringify(gameState), (err) => {
        if (err) console.warn("[Cloud] Ошибка сохранения:", err);
        else console.log("[Cloud] Сохранено");
      });
    }
  }
  loadGameState() {
    try {
      const saved = localStorage.getItem("kitsuSave");
      if (saved) {
        const parsed = JSON.parse(saved);
        gameState = { ...defaultGameState, ...parsed };
        console.log("[Load] Загружено из localStorage");
        this.updateUI();
      }
    } catch (e) {
      console.warn("[Load] localStorage ошибка:", e);
      gameState = { ...defaultGameState };
    }
  }
}
// Конкретные комнаты
class KuchnyaScene extends BaseRoomScene {
  constructor() {
    super("kuchnya", "kuchnya");
  }
}
class SpalnyaScene extends BaseRoomScene {
  constructor() {
    super("spalnya", "spalnya");
  }
}
class GostinnayaScene extends BaseRoomScene {
  constructor() {
    super("gostinnaya", "gostinnaya");
  }
}
class VannayaScene extends BaseRoomScene {
  constructor() {
    super("vannaya", "vannaya");
  }
}
class PrihozhayaScene extends BaseRoomScene {
  constructor() {
    super("prihozhaya", "prihozhaya");
  }
}
// Конфигурация Phaser
const config = {
  type: Phaser.AUTO,
  width: window.innerWidth,
  height: window.innerHeight,
  parent: "game-container",
  backgroundColor: "#000000",
  scene: [
    BootScene,
    IntroScene,
    LevelUpScene,
    GostinnayaScene,
    KuchnyaScene,
    SpalnyaScene,
    VannayaScene,
    PrihozhayaScene,
  ],
  physics: {
    default: "arcade",
    arcade: {
      debug: false,
    },
  },
  scale: {
    mode: Phaser.Scale.RESIZE,
    autoCenter: Phaser.Scale.CENTER_BOTH,
    width: window.innerWidth,
    height: window.innerHeight,
    orientation: false,
    expandParent: true,
  },
  callbacks: {
    postBoot: (game) => {
      window.game = game;
      console.log("[Game] Phaser успешно запущен");

      game.scale.on("resize", (gameSize) => {
        console.log(
          `[Resize] ${gameSize.width}×${gameSize.height}, orientation: ${
            game.scale.isPortrait ? "portrait" : "landscape"
          }`
        );
      });

      // UI элементы
      let dialogueBox = document.getElementById("dialogue-box");
      if (!dialogueBox) {
        dialogueBox = document.createElement("div");
        dialogueBox.id = "dialogue-box";
        dialogueBox.classList.add("hidden");
        dialogueBox.innerHTML = `
          <p id="dialogue-text"></p>
          <div class="dialogue-buttons"></div>
        `;
        dialogueBox.style.cssText = `
          position: absolute;
          bottom: 20px;
          left: 10%;
          width: 80%;
          background: rgba(0,0,0,0.7);
          color: white;
          padding: 20px;
          border-radius: 10px;
          z-index: 30;
          text-align: center;
        `;
        document.body.appendChild(dialogueBox);
      }

      let statusBar = document.querySelector(".status-bar");
      if (!statusBar) {
        statusBar = document.createElement("div");
        statusBar.className = "status-bar";
        statusBar.style.cssText = `
          position: absolute;
          top: 10px;
          left: 50px;
          display: flex;
          gap: 10px;
          align-items: center;
          z-index: 20;
        `;
        statusBar.innerHTML = `
          <div style="width: 100px; height: 10px; background: gray;"><div id="hunger-bar" style="height:100%; background:red;"></div></div>
          <div style="width: 100px; height: 10px; background: gray;"><div id="mood-bar" style="height:100%; background:blue;"></div></div>
          <div style="width: 100px; height: 10px; background: gray;"><div id="energy-bar" style="height:100%; background:green;"></div></div>
          <div style="width: 100px; height: 10px; background: gray;"><div id="cleanliness-bar" style="height:100%; background:purple;"></div></div>
          <span id="money" style="color: gold; font-size: 16px; padding-left: 10px;">0</span>
          <span id="level" style="color: white; font-size: 16px; padding-left: 10px;">1</span>
        `;
        document.body.appendChild(statusBar);
      }

      let timeDiv = document.getElementById("time-display");
      if (!timeDiv) {
        timeDiv = document.createElement("div");
        timeDiv.id = "time-display";
        timeDiv.style.cssText = `
          position: absolute;
          top: 10px;
          left: 10px;
          color: #e0f7fa;
          font-size: 16px;
          font-weight: 600;
          background: rgba(0,0,0,0.4);
          padding: 6px 12px;
          border-radius: 12px;
          z-index: 21;
          pointer-events: none;
        `;
        timeDiv.innerHTML = `<span id="time">08:00</span>`;
        document.body.appendChild(timeDiv);
      }

      let tasksDiv = document.getElementById("tasks-panel");
      if (!tasksDiv) {
        tasksDiv = document.createElement("div");
        tasksDiv.id = "tasks-panel";
        tasksDiv.style.cssText = `
          position: absolute;
          top: 50px;
          right: 10px;
          width: 220px;
          max-height: 180px;
          overflow-y: auto;
          background: rgba(10, 20, 50, 0.85);
          backdrop-filter: blur(8px);
          border-radius: 16px;
          padding: 12px;
          color: #e1f5fe;
          font-size: 14px;
          z-index: 20;
          border: 1px solid rgba(100, 200, 255, 0.3);
          box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        `;
        tasksDiv.innerHTML = `<strong style="display: block; margin-bottom: 8px;">Задания</strong><ul id="tasks-list" style="list-style-type: disc; padding-left: 20px;"></ul>`;
        document.body.appendChild(tasksDiv);
      }

      const currentScene = game.scene.getScenes(true)[0];
      if (currentScene && currentScene.updateUI) {
        currentScene.updateUI();
      }
    },
  },
};

// Google Fonts для аниме-шрифта
const fontLink = document.createElement("link");
fontLink.href =
  "https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap";
fontLink.rel = "stylesheet";
document.head.appendChild(fontLink);

// CSS keyframes
const style = document.createElement("style");
style.innerHTML = `
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }
  @keyframes glow {
    0% { box-shadow: 0 0 10px pink; }
    100% { box-shadow: 0 0 20px pink; }
  }
  .dialogue-box.cutscene, .dialogue-box.thought { /* стили */ }
  .dialogue-buttons button {
    margin: 5px;
    padding: 10px;
    background: #9d4edd;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  #tasks-panel li { margin-bottom: 5px; }
`;
document.head.appendChild(style);

// Запуск игры
const game = new Phaser.Game(config);
window.game = game;

// Обработчик room-switcher (если есть)
const roomBtns = document.querySelectorAll("#room-switcher button");
roomBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    const roomKey = btn.dataset.room;
    if (!gameState.unlockedRooms.includes(roomKey)) {
      showDialogue("Эта комната ещё не открыта!");
      btn.classList.add("disabled");
      return;
    }
    if (window.game) {
      const activeScene = game.scene.getScenes(true).find((s) => s.isActive());
      if (activeScene && activeScene.switchRoom) {
        activeScene.switchRoom(roomKey);
      } else {
        game.scene.start(roomKey);
        gameState.currentRoom = roomKey;
        const oldActions = document.getElementById("room-actions");
        if (oldActions) oldActions.remove();
      }
    }
  });
});

// Beforeunload
window.addEventListener("beforeunload", () => {
  if (game && game.scene) {
    const activeScene = game.scene.getScenes(true)[0];
    if (activeScene && activeScene.saveProgress) {
      activeScene.saveProgress();
    }
  }
});
